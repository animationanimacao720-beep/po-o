package com.dev.codeinjector

/** Linguagens aceitas pelo executor remoto/JavaScript legado. */
enum class Language {
    PYTHON,
    JAVASCRIPT,
    KOTLIN,
    CPP
}

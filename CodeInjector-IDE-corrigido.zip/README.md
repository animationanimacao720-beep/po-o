# CodeInjector IDE

Este repositório contém somente o app Android da IDE CodeInjector. A execução de scripts Python comuns continua local, pelo Chaquopy. Scripts que importam `kivy` ou `pygame` são encaminhados aos apps companion instalados separadamente.

## Compilar pelo celular com GitHub Actions

1. Crie um repositório GitHub para a IDE.
2. Extraia este ZIP e envie **todo o conteúdo** para a raiz do repositório. A pasta `.github/workflows/build.yml` deve ficar exatamente nesse caminho.
3. Abra a aba **Actions** e rode **Build APK** (ou faça um push para disparar o workflow).
4. Baixe o artefato `CodeInjector-debug-apk`, extraia-o e instale o APK no Android.

## Repositórios companion

Crie também dois repositórios independentes usando os ZIPs CodeInjector-Kivy e CodeInjector-Pygame. Compile e instale os dois apps para a IDE conseguir encaminhar scripts gráficos. Seus application IDs precisam permanecer:

- Kivy: `org.codeinjector.kivyrunner`
- Pygame: `org.codeinjector.pygamerunner`

A IDE consulta esses IDs e envia um ZIP temporário do projeto selecionado usando Android `FileProvider`. As edições ainda não salvas das abas abertas são incluídas.

## Importante

Os runners são aplicações Android nativas empacotadas via Buildozer/python-for-android, não pacotes instalados no runtime Chaquopy da IDE. Teste primeiro scripts pequenos. O build Pygame usa uma receita local comunitária experimental; seu workflow pode precisar de ajustes conforme a combinação de versões do Android NDK e python-for-android.

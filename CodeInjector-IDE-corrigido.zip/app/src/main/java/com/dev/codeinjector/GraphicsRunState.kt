package com.dev.codeinjector

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Estado/saída exibidos pelo console enquanto um app companion Kivy ou Pygame está aberto. */
object GraphicsRunState {
    private val _running = MutableStateFlow(false)
    val running = _running.asStateFlow()

    private val _output = MutableStateFlow("")
    val output = _output.asStateFlow()

    fun setMessage(message: String) {
        _running.value = false
        _output.value = message
    }

    fun setExternalMessage(message: String) {
        _output.value = message
        _running.value = true
    }

    /** Chamado quando o editor volta ao primeiro plano após fechar um runner. */
    fun onExternalRunnerReturned() {
        if (_running.value) {
            setMessage("[CodeInjector] Você voltou do app gráfico. O editor e o executor Python local continuam prontos.")
        }
    }

    fun clearOutput() {
        _output.value = ""
    }

    fun stopExternal() {
        if (!_running.value) return
        setMessage("[CodeInjector] Kivy/Pygame executa em um app separado. Volte ao app gráfico e use Voltar/Fechar para encerrar a execução.")
    }
}

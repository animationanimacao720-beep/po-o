package com.dev.codeinjector

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.compose.runtime.mutableStateListOf
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier

/** Arquivos recebidos de outros apps ("Abrir com") esperando para virar abas. */
object Incoming { val uris = mutableStateListOf<Uri>() }

class MainActivity : ComponentActivity() {
    private fun handle(i: Intent?) {
        if (i == null) return
        if ((i.action == Intent.ACTION_VIEW || i.action == Intent.ACTION_EDIT) && i.data != null) Incoming.uris.add(i.data!!)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        GraphicsRunState.onExternalRunnerReturned()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PyRunner.warmUp(applicationContext)   // inicia o CPython em segundo plano
        if (savedInstanceState == null) handle(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize().statusBarsPadding().imePadding()) { CodeEditorScreen() }
            }
        }
    }
}

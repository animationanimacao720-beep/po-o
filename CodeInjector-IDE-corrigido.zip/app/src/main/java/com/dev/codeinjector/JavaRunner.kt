package com.dev.codeinjector

import android.content.Context
import android.os.Handler
import android.os.Looper
import dalvik.system.DexClassLoader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintStream
import java.io.PrintWriter
import java.io.StringWriter
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Modifier
import java.nio.file.Path
import java.nio.file.Paths

/**
 * Java nativo: ECJ compila (.java -> .class), D8 converte (.class -> .dex),
 * DexClassLoader carrega e o main(String[]) roda com stdout/stderr capturados.
 * Precisa do android.jar (escolhido pelo usuário em Config.).
 */
object JavaRunner {
    private val main = Handler(Looper.getMainLooper())

    fun jarFile(ctx: Context) = File(ctx.filesDir, "android.jar")
    fun hasAndroidJar(ctx: Context) = jarFile(ctx).let { it.exists() && it.length() > 1_000_000 }

    fun run(ctx: Context, code: String, stdin: String, onResult: (String) -> Unit) {
        if (!hasAndroidJar(ctx)) {
            onResult("Falta o android.jar. Em Config., toque em \"Selecionar android.jar\"."); return
        }
        Thread(null, {
            val out = try { compileAndRun(ctx, code, stdin) }
            catch (t: Throwable) {
                val c = (t as? InvocationTargetException)?.targetException ?: t
                "[erro] ${c.javaClass.simpleName}: ${c.message}"
            }
            main.post { onResult(out) }
        }, "java-runner", 256L * 1024 * 1024).start()
    }

    private fun hasCompilerLibs() = runCatching {
        Class.forName("org.eclipse.jdt.core.compiler.batch.BatchCompiler"); Class.forName("com.android.tools.r8.D8")
    }.isSuccess

    // ECJ e D8 são chamados por reflexão: o app compila mesmo sem as dependências no Gradle.
    private fun runEcj(args: Array<String>, pw: PrintWriter): Boolean {
        val bc = Class.forName("org.eclipse.jdt.core.compiler.batch.BatchCompiler")
        val progress = Class.forName("org.eclipse.jdt.core.compiler.CompilationProgress")
        val m = bc.getMethod("compile", Array<String>::class.java, PrintWriter::class.java, PrintWriter::class.java, progress)
        return m.invoke(null, args, pw, pw, null) as Boolean
    }

    private fun runD8(files: List<Path>, lib: Path, out: Path) {
        val cmdC = Class.forName("com.android.tools.r8.D8Command")
        val modeC = Class.forName("com.android.tools.r8.OutputMode")
        val dexIndexed = modeC.enumConstants.first { (it as Enum<*>).name == "DexIndexed" }
        val b = cmdC.getMethod("builder").invoke(null)!!
        val bc = b.javaClass
        bc.getMethod("addProgramFiles", java.util.Collection::class.java).invoke(b, files)
        bc.getMethod("addLibraryFiles", Array<Path>::class.java).invoke(b, arrayOf(lib))
        bc.getMethod("setMinApiLevel", Int::class.javaPrimitiveType).invoke(b, 26)
        bc.getMethod("setOutput", Path::class.java, modeC).invoke(b, out, dexIndexed)
        val cmd = bc.getMethod("build").invoke(b)
        Class.forName("com.android.tools.r8.D8").getMethod("run", cmdC).invoke(null, cmd)
    }

    private fun compileAndRun(ctx: Context, code: String, stdin: String): String {
        if (!hasCompilerLibs()) return "Java nativo desativado: o ECJ e o D8 não estão no app.\n" +
            "Depois que o app compilar normalmente, descomente as duas linhas implementation(...) no app/build.gradle.kts."
        val work = File(ctx.cacheDir, "java-run").apply { deleteRecursively(); mkdirs() }
        val src = File(work, "src").apply { mkdirs() }
        val classes = File(work, "classes").apply { mkdirs() }
        val dexDir = File(work, "dex").apply { mkdirs() }

        val cls = Regex("public\\s+(?:final\\s+)?class\\s+(\\w+)").find(code)?.groupValues?.get(1)
            ?: Regex("\\bclass\\s+(\\w+)").find(code)?.groupValues?.get(1) ?: "Main"
        val file = File(src, "$cls.java").also { it.writeText(code) }
        val jar = jarFile(ctx).absolutePath

        // 1) ECJ: .java -> .class
        val log = StringWriter(); val pw = PrintWriter(log)
        val ok = runEcj(
            arrayOf("-1.8", "-nowarn", "-proc:none", "-encoding", "UTF-8",
                "-bootclasspath", jar, "-cp", jar, "-d", classes.absolutePath, file.absolutePath),
            pw
        )
        pw.flush()
        if (!ok) return "[erro de compilação]\n" + log.toString().replace(src.absolutePath + "/", "").trim()

        // 2) D8: .class -> .dex
        val classFiles = classes.walkTopDown().filter { it.isFile && it.extension == "class" }.toList()
        if (classFiles.isEmpty()) return "[nenhuma classe gerada]"
        runD8(classFiles.map { it.toPath() }, Paths.get(jar), dexDir.toPath())
        val dex = File(dexDir, "classes.dex")
        if (!dex.exists()) return "[D8 não gerou classes.dex]"
        dex.setReadOnly() // Android 14 exige dex somente leitura

        // 3) Carregar e achar o main
        val loader = DexClassLoader(dex.absolutePath, null, null, ctx.classLoader)
        val names = classFiles.map {
            classes.toPath().relativize(it.toPath()).toString().removeSuffix(".class").replace('/', '.')
        }
        val method = names.firstNotNullOfOrNull { n ->
            runCatching {
                loader.loadClass(n).getMethod("main", Array<String>::class.java).takeIf { Modifier.isStatic(it.modifiers) }
            }.getOrNull()
        } ?: return "[não achei 'public static void main(String[] args)']"

        // 4) Executar capturando a saída
        val buf = ByteArrayOutputStream()
        val ps = PrintStream(buf, true, "UTF-8")
        val oldOut = System.out; val oldErr = System.err; val oldIn = System.`in`
        System.setOut(ps); System.setErr(ps); System.setIn(ByteArrayInputStream(stdin.toByteArray()))
        var failure: Throwable? = null
        val t = Thread {
            try { method.invoke(null, arrayOf<String>()) }
            catch (e: InvocationTargetException) { failure = e.targetException }
            catch (e: Throwable) { failure = e }
        }
        t.isDaemon = true
        t.start(); t.join(10_000)
        val timedOut = t.isAlive
        System.setOut(oldOut); System.setErr(oldErr); System.setIn(oldIn)
        ps.flush()

        val sb = StringBuilder(buf.toString("UTF-8").trimEnd())
        failure?.let { f ->
            sb.append("\n[exceção] ").append(f.toString())
            f.stackTrace.take(5).forEach { sb.append("\n  at ").append(it) }
        }
        if (timedOut) sb.append("\n[timeout: passou de 10s; o programa continua em segundo plano]")
        return sb.toString().trim()
    }
}

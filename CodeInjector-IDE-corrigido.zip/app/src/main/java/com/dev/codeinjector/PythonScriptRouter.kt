package com.dev.codeinjector

/** Identifica o executor mais apropriado a partir dos imports do script Python. */
enum class PythonRunTarget {
    LOCAL,
    KIVY,
    PYGAME,
    BOTH_GRAPHICS
}

object PythonScriptRouter {
    // Reconhece imports diretos e listas como "import os, pygame" sem confundir
    // nomes parecidos (pygame_utils/kivy_helpers) com as bibliotecas reais.
    private val kivyImport = Regex(
        """(?m)^\s*(?:import\s+[^#\n]*\bkivy(?:\.[A-Za-z_]\w*)?(?:\s+as\s+\w+)?(?:\s*,|\s*$)|from\s+kivy(?:\.|\s|$))"""
    )
    private val pygameImport = Regex(
        """(?m)^\s*(?:import\s+[^#\n]*\bpygame(?:\.[A-Za-z_]\w*)?(?:\s+as\s+\w+)?(?:\s*,|\s*$)|from\s+pygame(?:\.|\s|$))"""
    )

    fun detect(source: String): PythonRunTarget {
        val usesKivy = kivyImport.containsMatchIn(source)
        val usesPygame = pygameImport.containsMatchIn(source)
        return when {
            usesKivy && usesPygame -> PythonRunTarget.BOTH_GRAPHICS
            usesKivy -> PythonRunTarget.KIVY
            usesPygame -> PythonRunTarget.PYGAME
            else -> PythonRunTarget.LOCAL
        }
    }
}

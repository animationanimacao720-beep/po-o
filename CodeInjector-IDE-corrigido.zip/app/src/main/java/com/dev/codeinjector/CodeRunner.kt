package com.dev.codeinjector

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/**
 * JavaScript: roda localmente num WebView (sem internet).
 * Python / Kotlin / C++: enviados a um servidor compatível com Judge0 (precisa de internet).
 */
object CodeRunner {
    private val main = Handler(Looper.getMainLooper())

    fun run(ctx: Context, lang: Language, code: String, stdin: String, baseUrl: String, token: String, onResult: (String) -> Unit) {
        if (lang == Language.JAVASCRIPT) { runJs(ctx, code, onResult); return }
        Thread {
            val out = try { remote(lang, code, stdin, baseUrl, token) } catch (e: Exception) { "[erro] ${e.message}" }
            main.post { onResult(out) }
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun runJs(ctx: Context, code: String, onResult: (String) -> Unit) {
        val sb = StringBuilder()
        var finished = false
        val wv = WebView(ctx)
        wv.settings.javaScriptEnabled = true
        fun finish(extra: String = "") {
            if (finished) return
            finished = true
            wv.destroy()
            synchronized(sb) { onResult(sb.toString() + extra) }
        }
        wv.addJavascriptInterface(object {
            @JavascriptInterface fun log(s: String) { synchronized(sb) { sb.appendLine(s) } }
            @JavascriptInterface fun done() { main.post { finish() } }
        }, "Native")
        main.postDelayed({ finish("[timeout: a execução passou de 5s]") }, 5000)

        val safe = code.replace("</script", "<\\/script")
        val html = """<html><body><script>
const __f = a => a.map(x => typeof x === 'object' ? JSON.stringify(x) : String(x)).join(' ');
console.log = (...a) => Native.log(__f(a));
console.info = console.log;
console.warn = (...a) => Native.log('[aviso] ' + __f(a));
console.error = (...a) => Native.log('[erro] ' + __f(a));
window.onerror = (m, s, l) => { Native.log('[erro] ' + m + ' (linha ' + l + ')'); };
window.addEventListener('unhandledrejection', e => Native.log('[erro] ' + e.reason));
</script><script>
$safe
</script><script>setTimeout(() => Native.done(), 1200);</script></body></html>"""
        wv.loadDataWithBaseURL("https://local.invalid/", html, "text/html", "utf-8", null)
    }

    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray())
    private fun unb64(s: String?): String =
        if (s.isNullOrEmpty() || s == "null") "" else String(Base64.getDecoder().decode(s.replace("\n", "")))

    private fun remote(lang: Language, code: String, stdin: String, baseUrl: String, token: String): String {
        val id = when (lang) { Language.PYTHON -> 71; Language.KOTLIN -> 78; Language.CPP -> 54; else -> return "Este tipo de arquivo não é executável." }
        val body = JSONObject().put("source_code", b64(code)).put("language_id", id).put("stdin", b64(stdin)).toString()
        val tk = JSONObject(http("POST", "$baseUrl/submissions?base64_encoded=true&wait=false", body, token)).getString("token")
        repeat(40) {
            Thread.sleep(1000)
            val r = JSONObject(http("GET", "$baseUrl/submissions/$tk?base64_encoded=true&fields=stdout,stderr,compile_output,message,status,time", null, token))
            val st = r.optJSONObject("status")
            if (st != null && st.getInt("id") > 2) {
                val sb = StringBuilder()
                unb64(r.optString("stdout")).let { if (it.isNotEmpty()) sb.append(it).append('\n') }
                unb64(r.optString("compile_output")).let { if (it.isNotEmpty()) sb.append("[compilação]\n").append(it).append('\n') }
                unb64(r.optString("stderr")).let { if (it.isNotEmpty()) sb.append("[stderr]\n").append(it).append('\n') }
                unb64(r.optString("message")).let { if (it.isNotEmpty()) sb.append(it).append('\n') }
                sb.append("— ${st.optString("description")} · ${r.optString("time")}s")
                return sb.toString()
            }
        }
        return "[timeout aguardando o servidor]"
    }

    private fun http(method: String, url: String, body: String?, token: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 10000; c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        if (token.isNotBlank()) c.setRequestProperty("X-Auth-Token", token)
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val text = (if (code >= 400) c.errorStream else c.inputStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code >= 400) throw Exception("HTTP $code: ${text.take(300)}")
        return text
    }
}

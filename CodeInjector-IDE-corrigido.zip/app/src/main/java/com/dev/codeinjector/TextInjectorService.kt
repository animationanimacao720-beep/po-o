package com.dev.codeinjector

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.*
import android.graphics.drawable.Icon
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.content.ContextCompat

enum class InjectResult { SET_TEXT, PASTE, CLIPBOARD, NO_TARGET }

class TextInjectorService : AccessibilityService() {

    companion object {
        const val ACTION_INJECT = "com.dev.codeinjector.INJECT"
        private const val CHANNEL = "injector"
        @Volatile var instance: TextInjectorService? = null
        @Volatile var pendingText: String = ""

        const val CA_PKG = "com.tyron.code"
        /** Estado da sincronização com o editor do CodeAssist (aba atual do CodeInjector). */
        class SyncState(val tabId: Int, val name: String, @Volatile var base: String, @Volatile var text: String, val onApplied: (String) -> Unit)
        @Volatile var sync: SyncState? = null

        fun isEnabled(ctx: Context): Boolean {
            val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(ctx, TextInjectorService::class.java)
            // O Android pode gravar a forma curta ("pkg/.Service"); unflatten entende as duas.
            return s.split(':').any { ComponentName.unflattenFromString(it.trim()) == me }
        }

        fun message(r: InjectResult) = when (r) {
            InjectResult.SET_TEXT -> "Código injetado"
            InjectResult.PASTE -> "Colado via prancheta (ACTION_PASTE)"
            InjectResult.CLIPBOARD -> "Não deu para injetar: código copiado. Cole no campo (ou pela prancheta da Gboard)"
            InjectResult.NO_TARGET -> "Nenhum campo focado: código copiado para a prancheta"
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // Se o processo reiniciou, pendingText está vazio: recupera o texto salvo da sessão.
            val text = pendingText.ifEmpty { SessionStore(this@TextInjectorService).currentText() }
            if (text.isEmpty()) {
                Toast.makeText(this@TextInjectorService, "Editor vazio: nada para injetar", Toast.LENGTH_SHORT).show()
            } else {
                injectLater(text, 300) { Toast.makeText(this@TextInjectorService, message(it), Toast.LENGTH_SHORT).show() }
            }
        }
    }

    override fun onServiceConnected() {
        instance = this
        ContextCompat.registerReceiver(this, receiver, IntentFilter(ACTION_INJECT), ContextCompat.RECEIVER_NOT_EXPORTED)
        postNotification()
    }

    private val syncRun = Runnable { trySync() }
    private var lastWarn = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.packageName?.toString() != CA_PKG || sync == null) return
        handler.removeCallbacks(syncRun)
        handler.postDelayed(syncRun, 500)
    }

    private fun norm(s: String) = s.replace("\r\n", "\n").trimEnd()

    private fun collectEditable(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (n == null || depth > 40) return
        if (n.isEditable) out.add(n)
        for (i in 0 until n.childCount) collectEditable(n.getChild(i), out, depth + 1)
    }

    /**
     * Quando o CodeAssist vem para a frente: se o editor dele mostra o texto ANTIGO do arquivo
     * (o que tínhamos antes das edições), troca pelo texto novo. Se não confere, não sobrescreve nada.
     */
    private fun trySync() {
        val st = sync ?: return
        val newText = st.text
        if (norm(newText) == norm(st.base)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != CA_PKG) return
        val nodes = ArrayList<AccessibilityNodeInfo>().also { collectEditable(root, it) }
        val target = nodes.firstOrNull { norm(it.text?.toString().orEmpty()) == norm(st.base) }
        if (target == null) {
            if (nodes.any { norm(it.text?.toString().orEmpty()) == norm(newText) }) { st.base = newText; st.onApplied(newText); return }
            val now = System.currentTimeMillis()
            if (now - lastWarn > 6000) {
                lastWarn = now
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("code", newText))
                Toast.makeText(this, "CodeAssist: abra o arquivo \"${st.name}\" (texto não confere). Código copiado.", Toast.LENGTH_LONG).show()
            }
            return
        }
        val ok = target.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText) }
        )
        handler.postDelayed({
            target.refresh()
            if (ok && norm(target.text?.toString().orEmpty()) == norm(newText)) {
                st.base = newText; st.onApplied(newText)
                Toast.makeText(this, "CodeAssist atualizado", Toast.LENGTH_SHORT).show()
            } else {
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("code", newText))
                Toast.makeText(this, "CodeAssist não aceitou a troca: código copiado (selecionar tudo + colar)", Toast.LENGTH_LONG).show()
            }
        }, 200)
    }
    override fun onInterrupt() {}

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        instance = null
        super.onDestroy()
    }

    private fun postNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Injetor", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(ACTION_INJECT).setPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_edit), "Injetar código", pi
        ).build()
        nm.notify(1, Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Code Injector")
            .setContentText("Foque um campo em outro app e toque em Injetar")
            .setOngoing(true).addAction(action).build())
    }

    private fun findTarget(): AccessibilityNodeInfo? {
        val roots = buildList {
            rootInActiveWindow?.let { add(it) }
            windows.forEach { w -> w.root?.let { add(it) } }
        }.filter {
            val p = it.packageName?.toString()
            p != packageName && p != "com.android.systemui"
        }
        val focused = roots.mapNotNull { it.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }
        return focused.firstOrNull { it.isEditable } ?: focused.firstOrNull()
    }

    /**
     * Cadeia: ACTION_SET_TEXT (verificado) → prancheta + ACTION_PASTE → só prancheta
     * (aí o usuário cola pela Gboard). Sem campo focado, o código fica na prancheta.
     */
    fun inject(code: String, onDone: (InjectResult) -> Unit) {
        val cm = getSystemService(ClipboardManager::class.java)
        fun toClipboard() = cm.setPrimaryClip(ClipData.newPlainText("code", code))
        val node = findTarget()
        if (node == null) { toClipboard(); onDone(InjectResult.NO_TARGET); return }

        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        var s = node.textSelectionStart; var e = node.textSelectionEnd
        if (s < 0 || e < 0) { s = current.length; e = s }
        val a = minOf(s, e).coerceIn(0, current.length)
        val b = maxOf(s, e).coerceIn(a, current.length)
        val result = current.substring(0, a) + code + current.substring(b)

        fun fallback() {
            toClipboard()
            val pasted = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            onDone(if (pasted) InjectResult.PASTE else InjectResult.CLIPBOARD)
        }
        if (!node.isEditable) { fallback(); return }

        val ok = node.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, result) }
        )
        if (!ok) { fallback(); return }

        handler.postDelayed({
            node.refresh()
            val after = node.text?.toString().orEmpty()
            if (code.isNotEmpty() && after == current) fallback() // o app ignorou o SET_TEXT
            else {
                val pos = a + code.length
                node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
                })
                onDone(InjectResult.SET_TEXT)
            }
        }, 150)
    }

    fun injectLater(code: String, delayMs: Long, onDone: (InjectResult) -> Unit) {
        handler.postDelayed({ inject(code, onDone) }, delayMs)
    }
}

package com.dev.codeinjector

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.io.ByteArrayOutputStream

data class DocEntry(val id: String, val name: String, val isDir: Boolean)

/** Acesso a uma pasta escolhida pelo seletor do Android (SAF), por exemplo a pasta de um projeto do CodeAssist. */
object ProjectFs {
    private const val MAX_BYTES = 2_000_000

    /** Lista os filhos diretos de [docId]; pastas primeiro, depois por nome. */
    fun list(ctx: Context, tree: Uri, docId: String): List<DocEntry> = runCatching {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val out = ArrayList<DocEntry>()
        ctx.contentResolver.query(
            children,
            arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                out += DocEntry(c.getString(0), c.getString(1) ?: "?", c.getString(2) == Document.MIME_TYPE_DIR)
            }
        }
        out.sortedWith(compareBy<DocEntry>({ !it.isDir }, { it.name.lowercase() }))
    }.getOrDefault(emptyList())

    /** Lê o arquivo como texto UTF-8. Retorna null se for grande demais (>2 MB) ou binário. */
    fun readText(ctx: Context, uri: Uri): String? = runCatching {
        val size = ctx.contentResolver.query(uri, arrayOf(Document.COLUMN_SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
        } ?: -1L
        if (size > MAX_BYTES) return@runCatching null
        val buf = ByteArrayOutputStream()
        ctx.contentResolver.openInputStream(uri)!!.use { input ->
            val chunk = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(chunk)
                if (n < 0) break
                total += n
                if (total > MAX_BYTES) return@runCatching null
                buf.write(chunk, 0, n)
            }
        }
        val bytes = buf.toByteArray()
        val lim = minOf(bytes.size, 8000)
        if ((0 until lim).any { bytes[it].toInt() == 0 }) return@runCatching null
        String(bytes, Charsets.UTF_8)
    }.getOrNull()

    fun docUri(tree: Uri, docId: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)

    /** Cria arquivo ou pasta em [parentId]. Retorna o Uri do novo documento ou null. */
    fun create(ctx: Context, tree: Uri, parentId: String, name: String, isDir: Boolean): Uri? = runCatching {
        val mime = if (isDir) Document.MIME_TYPE_DIR else "application/octet-stream"
        DocumentsContract.createDocument(ctx.contentResolver, docUri(tree, parentId), mime, name)
    }.getOrNull()

    /** Renomeia; retorna o novo documentId (ou null se o provedor recusar). */
    fun rename(ctx: Context, tree: Uri, docId: String, newName: String): String? = runCatching {
        DocumentsContract.renameDocument(ctx.contentResolver, docUri(tree, docId), newName)?.let { DocumentsContract.getDocumentId(it) }
    }.getOrNull()

    fun delete(ctx: Context, tree: Uri, docId: String): Boolean =
        runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, docUri(tree, docId)) }.getOrDefault(false)

    /** Move para outra pasta; retorna o novo documentId. */
    fun move(ctx: Context, tree: Uri, docId: String, fromParentId: String, toParentId: String): String? = runCatching {
        DocumentsContract.moveDocument(ctx.contentResolver, docUri(tree, docId), docUri(tree, fromParentId), docUri(tree, toParentId))
            ?.let { DocumentsContract.getDocumentId(it) }
    }.getOrNull()

    fun writeText(ctx: Context, uri: Uri, text: String): Boolean = runCatching {
        ctx.contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter().use { it.write(text) }; true
    }.getOrDefault(false)

    /**
     * Atualiza o Uri de uma aba depois de renomear/mover/excluir [oldId] (arquivo ou pasta).
     * Retorna: o novo Uri; o mesmo Uri se não foi afetado; null se o arquivo foi excluído.
     */
    fun remap(uri: Uri, tree: Uri, oldId: String, newId: String?): Uri? {
        val id = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull() ?: return uri
        if (id != oldId && !id.startsWith("$oldId/")) return uri
        if (newId == null) return null
        return docUri(tree, newId + id.removePrefix(oldId))
    }
}

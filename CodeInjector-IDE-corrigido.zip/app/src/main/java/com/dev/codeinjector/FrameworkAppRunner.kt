package com.dev.codeinjector

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Uma aba imutável no instante em que o usuário toca em Executar. */
data class RunnerTabSnapshot(
    val id: Int,
    val name: String,
    val text: String,
    val uri: Uri?
)

/**
 * Empacota o projeto e o encaminha para um app Android separado, compilado com a
 * cadeia nativa própria de Kivy ou Pygame. Não executa bibliotecas gráficas no Chaquopy.
 */
object FrameworkAppRunner {
    const val EXTRA_PROJECT_URI = "org.codeinjector.runner.PROJECT_URI"
    private const val FILE_PROVIDER_SUFFIX = ".fileprovider"
    private const val MAX_PROJECT_FILES = 500
    private const val MAX_PROJECT_BYTES = 64L * 1024L * 1024L
    private const val MAX_DEPTH = 24

    private val ignoredDirectories = setOf(
        ".git", ".idea", ".gradle", ".venv", "venv", "__pycache__", "node_modules",
        "build", "dist", "bin", "target", ".pytest_cache", ".mypy_cache"
    )
    private val ignoredExtensions = setOf("apk", "aab", "aar", "dex", "class", "jar", "so", "o", "pyc")

    fun packageName(target: PythonRunTarget): String = when (target) {
        PythonRunTarget.KIVY -> "org.codeinjector.kivyrunner"
        PythonRunTarget.PYGAME -> "org.codeinjector.pygamerunner"
        else -> error("Framework gráfico inválido: $target")
    }

    fun displayName(target: PythonRunTarget): String = when (target) {
        PythonRunTarget.KIVY -> "CodeInjector Kivy Runner"
        PythonRunTarget.PYGAME -> "CodeInjector Pygame Runner"
        else -> "CodeInjector Runner"
    }

    fun isInstalled(ctx: Context, target: PythonRunTarget): Boolean = runCatching {
        ctx.packageManager.getLaunchIntentForPackage(packageName(target)) != null
    }.getOrDefault(false)

    /**
     * Cria um ZIP temporário com o projeto SAF inteiro, sobrescrevendo os arquivos que
     * estão abertos no editor pelo texto atual (inclusive alterações ainda não salvas).
     */
    fun createProjectArchive(
        ctx: Context,
        target: PythonRunTarget,
        activeTabId: Int,
        tabs: List<RunnerTabSnapshot>,
        treeUri: Uri?,
        rootId: String?
    ): File {
        require(target == PythonRunTarget.KIVY || target == PythonRunTarget.PYGAME) {
            "O arquivo não selecionou um executor gráfico válido."
        }
        require(tabs.isNotEmpty()) { "Não há nenhuma aba para executar." }
        val active = tabs.firstOrNull { it.id == activeTabId }
            ?: throw IllegalArgumentException("Não foi possível identificar a aba atual.")

        val cacheRoot = File(ctx.cacheDir, "runner-projects").apply { mkdirs() }
        cacheRoot.listFiles()?.filter { it.isFile && System.currentTimeMillis() - it.lastModified() > 48L * 60L * 60L * 1000L }
            ?.forEach { it.delete() }
        val archive = File(cacheRoot, "project-${target.name.lowercase()}-${System.currentTimeMillis()}.zip")

        val pathsById = LinkedHashMap<Int, String>()
        val usedPaths = mutableSetOf<String>()
        tabs.forEachIndexed { index, tab ->
            val fromUri = relativePathFromUri(tab.uri, treeUri, rootId)
            val preferred = safeRelative(fromUri ?: tab.name)
            var path = preferred ?: "main.py"
            if (path in usedPaths || path.startsWith("__codeinjector__/")) {
                val fileName = path.substringAfterLast('/').ifBlank { "script.py" }
                path = safeRelative("__open_tabs__/${index}_${fileName}") ?: "__open_tabs__/${index}_script.py"
            }
            usedPaths.add(path)
            pathsById[tab.id] = path
        }
        val activePath = pathsById[active.id] ?: safeRelative(active.name) ?: "main.py"
        val openPaths = pathsById.values.toSet()
        var totalBytes = 0L
        var fileCount = 0
        val inserted = mutableSetOf<String>()

        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(archive))).use { zip ->
                fun beginEntry(path: String) {
                    zip.putNextEntry(ZipEntry(path))
                    inserted.add(path)
                    fileCount++
                    if (fileCount > MAX_PROJECT_FILES) throw IllegalStateException(
                        "O projeto possui mais de $MAX_PROJECT_FILES arquivos. Remova pastas de build e tente novamente."
                    )
                }

                // Copia os recursos de projeto escolhidos no navegador de arquivos do Android.
                if (treeUri != null && !rootId.isNullOrBlank()) {
                    val pending = ArrayDeque<Triple<String, String, Int>>()
                    pending.add(Triple(rootId, "", 0))
                    val visited = mutableSetOf<String>()
                    while (pending.isNotEmpty() && fileCount < MAX_PROJECT_FILES) {
                        val (parentId, prefix, depth) = pending.removeFirst()
                        if (!visited.add(parentId) || depth > MAX_DEPTH) continue
                        for (entry in ProjectFs.list(ctx, treeUri, parentId)) {
                            val relative = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
                            if (entry.isDir) {
                                if (entry.name !in ignoredDirectories && depth < MAX_DEPTH) {
                                    pending.add(Triple(entry.id, relative, depth + 1))
                                }
                                continue
                            }
                            val path = safeRelative(relative) ?: continue
                            if (path in openPaths || path.startsWith("__codeinjector__/")) continue
                            if (path.substringAfterLast('.', "").lowercase() in ignoredExtensions) continue
                            if (path in inserted) continue
                            val input = runCatching {
                                ctx.contentResolver.openInputStream(ProjectFs.docUri(treeUri, entry.id))
                            }.getOrNull() ?: continue
                            input.use { stream ->
                                beginEntry(path)
                                val buffer = ByteArray(16 * 1024)
                                while (true) {
                                    val count = stream.read(buffer)
                                    if (count < 0) break
                                    totalBytes += count
                                    if (totalBytes > MAX_PROJECT_BYTES) throw IllegalStateException(
                                        "O projeto passou de 64 MB. Remova arquivos grandes desnecessários e tente novamente."
                                    )
                                    zip.write(buffer, 0, count)
                                }
                                zip.closeEntry()
                            }
                        }
                    }
                }

                // O texto aberto no editor tem prioridade sobre o arquivo salvo no disco.
                tabs.forEach { tab ->
                    val path = pathsById[tab.id] ?: return@forEach
                    if (path in inserted) return@forEach
                    val content = tab.text.toByteArray(Charsets.UTF_8)
                    totalBytes += content.size
                    if (totalBytes > MAX_PROJECT_BYTES) throw IllegalStateException(
                        "O projeto passou de 64 MB. Remova arquivos grandes desnecessários e tente novamente."
                    )
                    beginEntry(path)
                    zip.write(content)
                    zip.closeEntry()
                }

                val manifest = JSONObject()
                    .put("version", 1)
                    .put("framework", if (target == PythonRunTarget.KIVY) "kivy" else "pygame")
                    .put("entry", activePath)
                    .toString()
                    .toByteArray(Charsets.UTF_8)
                beginEntry("__codeinjector__/manifest.json")
                zip.write(manifest)
                zip.closeEntry()
            }
        } catch (e: Exception) {
            archive.delete()
            throw e
        }
        return archive
    }

    /** Inicia o app companion, dando a ele acesso temporário de leitura ao ZIP via FileProvider. */
    fun launch(ctx: Context, target: PythonRunTarget, archive: File): String? {
        val packageName = packageName(target)
        val repositoryName = if (target == PythonRunTarget.KIVY) "CodeInjector-Kivy" else "CodeInjector-Pygame"
        val intent = ctx.packageManager.getLaunchIntentForPackage(packageName)
            ?: return "${displayName(target)} não está instalado. Compile o repositório $repositoryName no GitHub Actions, baixe o artefato APK e instale-o. Depois tente Executar novamente."
        return runCatching {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + FILE_PROVIDER_SUFFIX, archive)
            ctx.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.data = uri
            intent.putExtra(EXTRA_PROJECT_URI, uri.toString())
            intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            ctx.startActivity(intent)
            null
        }.getOrElse { e ->
            "Não foi possível abrir ${displayName(target)}: ${e.message ?: e.javaClass.simpleName}. Confirme se o APK companion está instalado."
        }
    }

    private fun relativePathFromUri(uri: Uri?, treeUri: Uri?, rootId: String?): String? {
        if (uri == null || treeUri == null || rootId.isNullOrBlank()) return null
        val documentId = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull() ?: return null
        if (!documentId.startsWith("$rootId/")) return null
        return documentId.removePrefix("$rootId/")
    }

    private fun safeRelative(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val normalized = raw.replace('\\', '/').trimStart('/')
        val parts = normalized.split('/').filter { it.isNotEmpty() }
        if (parts.isEmpty() || parts.any { it == "." || it == ".." || it.contains('\u0000') }) return null
        val result = parts.joinToString("/")
        if (result == "__codeinjector__" || result.startsWith("__codeinjector__/")) return null
        return result
    }
}
